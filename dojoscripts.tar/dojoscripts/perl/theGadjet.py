#!/usr/bin/env python

from Tkinter import *

class Gui(Frame):
	   
	def __init__(self, parent):
		Frame.__init__(self, parent)
		self.grid()
		self.canvas = Canvas(self,width=1280,height=80)
		self.canvas.grid()


	def draw(self):
		self.canvas.create_rectangle(0,0,1280,80,fill=self.getFill())
		self.canvas.grid()
		self.after(1000, self.draw)

  	def getFill(self):
		file = open("/tmp/pystate","r")
		state = file.read()
		file.close()
		return state


top=Tk()
gui = Gui(top)
gui.draw()
top.mainloop()