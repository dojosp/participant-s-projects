#!/usr/bin/perl
use Term::ANSIColor;
use strict;
use warnings;

my $mode = 'green';


#Green < Red < Yellow
# Ok < Fail < Error
my %precedence = ("green", 0, "red" , 1, "yellow" ,2);

sub setState {
	my $current = shift;
	if ($precedence{$current} > $precedence{$mode}){
		$mode = $current;
	}
	my $color = 'bold ' . $current;
	print color $color;
}

sub parse {
	my $s = shift;
	open(IN,'-');
	while (<IN>){
		my @thing = split $s,$_;

		foreach my $item  (@thing){
			if ($item eq 'F' or $item eq 'FAILED'){
				setState('red');
			} elsif ($item eq '.' or $item eq 'OK'){
				setState('green');
			} elsif ($item eq 'E' or $item eq 'ERROR'){
				setState('yellow');
			}
			chomp($item);
			print $item . $s;
			print color 'reset';
		}
	
		print "\n";

		if ($s eq ''){
			last;
		}
	}

	close(IN);

}

parse('');
parse(' ');

open(FILE,'>/tmp/pystate');
print FILE $mode;
close(FILE);
