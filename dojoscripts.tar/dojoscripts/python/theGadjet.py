#!/usr/bin/env python

from Tkinter import *
import sys
import string
import os

class PyColor:
	red = "\033[1;31m"
	green = "\033[1;32m"
	yellow = "\033[1;33m"
	reset = "\033[1;0m"
	
	#Green < Red < Yellow
	# Ok < Fail < Error
	precedence = {'green':0,'red':1,'yellow':2}
	color = {'green':green,'red':red,'yellow':yellow}
	mode = 'green'
	
	def __init__(self,file,useColors,useYellow):
		self.useColors = useColors
		self.useYellow = useYellow
		self.file = file
	
	def setState(self,current):
		self.mode
		if (self.precedence[current] > self.precedence[self.mode]):
			self.mode = current
		return self.color[current]
	
	def parseItem(self,word):
		clr = ''
		word = string.rstrip(string.lstrip(word))
		#print "word:"+ color['green'] + word + reset+":"
		if word == 'F' or word == 'FAILED':
			clr = self.setState('red')
		elif word == '.' or word == "OK":
			clr = self.setState('green')
		elif (word == 'E' or word == 'ERROR'):
			if (self.useYellow):
				clr = self.setState('yellow')
			else:
				clr = self.setState('red')
		#if self.useColor == True:
			#return clr + word
		#return word
		return clr +word

	def parseLines(self,spl,file):
		print ''
		for line in file:
			if spl != '':
				for word in line.split(spl):
					print self.parseItem(word) + spl + self.reset,		
			else:
				for word in line:
					print self.parseItem(word) + spl + self.reset,
				print ''
				return
			print ''
		print ''
				
	def parse(self):
		try:
			file = open(self.file,"r")
			self.mode = 'green'
			self.parseLines('',file)
			self.parseLines(' ',file)
			file.close()
			os.remove(self.file)
		except:
			pass

class Gui(Frame):
	def __init__(self, parent,sentinel):
		self.sentinel = sentinel
		Frame.__init__(self, parent)
		self.grid()
		self.canvas = Canvas(self,width=1280,height=80)
		self.canvas.create_rectangle(0,0,1280,80,fill=self.getFill(),tags="rect")
		self.canvas.grid()


	def draw(self):
		self.canvas.itemconfigure("rect",fill=self.getFill())
		self.after(500, self.draw)

  	def getFill(self):
		self.sentinel.parse()
		return self.sentinel.mode


def help():
	print "The Gadjet help"
	print "program -[options] file"
	print "		c	Don't use COLORS (don't really work nice yet)"
	print "		h	show this HELP"
	print "		y	YELLOW means red"
	print ''

def parseArgs(args):
	helped = False
	useColors = True
	useYellow = True
	count = 0
	for arg in args:
		if (arg == '-c'):
			useColors = False
			count += 1
		if (arg == '-y'):
			useYellow = False
			count += 1
		if (arg == '-h' and (not helped)):
			helped = True;
			help()
			count += 1
		
	
	return (useColors,useYellow,count,helped)

if __name__=='__main__':
	(useColors,useYellow,count,helped) = parseArgs(sys.argv);
	if len(sys.argv) - count >= 2:
		top=Tk()
		print "Reading " + sys.argv[-1]
		sentinel = PyColor(sys.argv[-1],useColors,useYellow)
		gui = Gui(top,sentinel)
		gui.draw()
		top.mainloop()
	else:
		if (not helped):
			print "Dont't you forget to tell me where to look for test results?"
